export default {
<<<<<<< HEAD
  primaryColor: "#757de8",
  accentColor: "#f44336",
=======
  primaryColor: "#7986cb",
  accentColor: "#C2185B",
>>>>>>> 968011327f9785bbb767ceac899a99f8ac5f294a
  albastru: "#29b6f6",
  verde: "#66bb6a",
  roz: "#f06292",
  portocaliu: "#ffc107",
};
