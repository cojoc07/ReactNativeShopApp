export default {
  url: "https://shopapp-3455a.firebaseio.com",
  apikey: "AIzaSyDDAPQ7qQnQzyluUVtcjF9Kb1gen7kpOZg",
};
